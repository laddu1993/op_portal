import { Component } from '@angular/core';

@Component({
  selector: 'app-submit-output-message',
  templateUrl: './submit-output-message.component.html',
  styleUrls: ['./submit-output-message.component.css']
})
export class SubmitOutputMessageComponent {

}
