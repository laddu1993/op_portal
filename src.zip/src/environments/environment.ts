export const environment = {
    production: false,
    uat: true,
    assetUrl: '/assets/', // Update this path based on your actual setup
    name: "(UAT)",
    CRMURL: `https://husqvarna--tst.custhelp.com/cc/husqvarna_api/`,
    apiURL: `http://localhost/op-portal/op-api/api/v1.0/`
}