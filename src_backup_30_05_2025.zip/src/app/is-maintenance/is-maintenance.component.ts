import { Component } from '@angular/core';

@Component({
  selector: 'app-is-maintenance',
  templateUrl: './is-maintenance.component.html',
  styleUrls: ['./is-maintenance.component.scss']
})
export class IsMaintenanceComponent {

}
