import { Component } from '@angular/core';

@Component({
  selector: 'app-delete-template-popup',
  templateUrl: './delete-template-popup.component.html',
  styleUrls: ['./delete-template-popup.component.css']
})
export class DeleteTemplatePopupComponent {

}
