import { Component, Output, EventEmitter, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DialogRef } from '@angular/cdk/dialog';
import { MasterService } from 'src/app/apiservice/master.service';
import { AddNewItem } from 'src/app/Model/UserObject';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-additem',
  templateUrl: './additem.component.html',
  styleUrls: ['./additem.component.css']
})
export class AdditemComponent {

  @Output() addItemEvent = new EventEmitter<{ blank: string, sku: number, desc: string, price: number, quantity: number }>();
  sku: number | null = null;
  products: AddNewItem[] | any;
  jsonData: any;
  quantity: number = 1; // Default quantity
  errorMessage: string | null = null; // Add this property to your component
  assetUrl = environment.assetUrl;
  @ViewChild('skuInput') skuInput!: ElementRef;

  constructor(private dialog: MatDialog, private service: MasterService, public dialogRef: DialogRef<any>) { }

  ngAfterViewInit() {
    this.skuInput.nativeElement.focus(); // Auto-focus the input field after the view initializes
  }

  closePopUp(){
    this.dialogRef.close();
  }

  searchSKU(): void {
    // Reset the error message before performing the search
    this.errorMessage = null;
    // Check if `this.sku` is not null and is a valid number
    if (this.sku !== null && !isNaN(this.sku)) {
      this.service.getaddItemSearch(this.sku.toString()).subscribe(data => {
        this.jsonData = data;
        if (this.jsonData.status == 'failed') {
          this.errorMessage = this.jsonData.message;
        } else {
          this.jsonData = data;
          this.products = this.jsonData.results;
        }
      });
    } else {
      this.errorMessage = 'Please enter a valid Product SKU';
    }
  }  

  addItenBtn(): void{
    if (this.products) {
      const { blank, sku, desc, price } = this.products; // Destructure the product object
      console.log('Closing with data:', { blank, sku, desc, price, quantity: this.quantity });
      this.addItemEvent.emit({ blank, sku, desc, price, quantity: this.quantity });
      this.dialogRef.close({ blank, sku, desc, price, quantity: this.quantity });
    } else {
      this.errorMessage = 'No product selected';
    }
  }

  onInput(event: Event) {
    const input = event.target as HTMLInputElement;
    const value = input.value;

    // Remove any non-numeric characters
    const numericValue = value.replace(/[^0-9]/g, '');
    
    // Update the model with numeric value
    this.sku = numericValue ? Number(numericValue) : null;
    
    // Optionally, update the input field to reflect the cleaned value
    input.value = this.sku?.toString() || '';
  }

}
