import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { saveAs } from 'file-saver';
//import * as XLSX from 'xlsx';
import { Observable } from 'rxjs';
import { AccountService } from './account.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ExcelDownloadService {

  private apiUrl = environment.apiURL;
  acct: string | null = null;
  constructor(private http: HttpClient, private accountService: AccountService ) { }

  downloadExcelFile(): Observable<Blob> {
    this.acct = this.accountService.getAccount(); // Get the acct parameter
    return this.http.get(this.apiUrl+`pp_excel_download?compCode=USF&acctNum=`+ this.acct, { responseType: 'blob' });
  }

  saveExcelFile(data: Blob, fileName: string): void {
    saveAs(data, fileName);
  }

}