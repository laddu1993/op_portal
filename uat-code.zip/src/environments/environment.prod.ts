export const environment = {
    production: true,
    assetUrl: '/assets/', // Update this path based on your actual setup
    name: "(Prod)",
    CRMURL: `https://husqvarna--tst.custhelp.com/cc/husqvarna_api/`,
    apiURL: `https://webappsusa.husqvarnagroup.com/new_partsportal/backend/`
}