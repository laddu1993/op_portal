export const environment = {
    production: false,
    uat: true,
    assetUrl: '/uat_op_portal/assets/', // Update this path based on your actual setup
    name: "(UAT)",
    CRMURL: `https://husqvarna--tst.custhelp.com/cc/husqvarna_api/`,
    apiURL: `https://crmapps.husqvarnagroup.com/uat_op_portal/api/rest/v1.0/`
}