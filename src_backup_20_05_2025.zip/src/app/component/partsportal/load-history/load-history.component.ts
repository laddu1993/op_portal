import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';

interface LoadHistory {
  orderId: string;
  date: Date;
  total: number;
  status: string;
}

@Component({
  selector: 'app-load-history',
  templateUrl: './load-history.component.html',
  styleUrls: ['./load-history.component.scss']
})
export class LoadHistoryComponent implements OnInit, AfterViewInit {
  displayedColumns: string[] = ['orderId', 'date', 'total', 'status'];
  dataSource = new MatTableDataSource<LoadHistory>([]);
  isLoading = true;
  totalRecords = 0;

  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor() {}

  ngOnInit(): void {
    // Simulate fetching data (replace with actual API call)
    this.fetchLoadHistory();
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }

  fetchLoadHistory(): void {
    // Mock data - replace with API call
    setTimeout(() => {
      const mockData: LoadHistory[] = [
        { orderId: 'ORD001', date: new Date('2025-01-15'), total: 1500.75, status: 'Completed' },
        { orderId: 'ORD002', date: new Date('2025-02-10'), total: 2300.20, status: 'Pending' },
        { orderId: 'ORD003', date: new Date('2025-03-05'), total: 890.50, status: 'Shipped' },
        { orderId: 'ORD004', date: new Date('2025-04-20'), total: 4500.00, status: 'Completed' },
        { orderId: 'ORD005', date: new Date('2025-05-01'), total: 1200.30, status: 'Cancelled' },
        { orderId: 'ORD006', date: new Date('2025-04-15'), total: 3200.10, status: 'Processing' },
        { orderId: 'ORD007', date: new Date('2025-03-20'), total: 670.25, status: 'Completed' }
      ];
      this.dataSource.data = mockData;
      this.totalRecords = mockData.length;
      this.isLoading = false;
    }, 1000); // Simulate loading delay
  }

  applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}